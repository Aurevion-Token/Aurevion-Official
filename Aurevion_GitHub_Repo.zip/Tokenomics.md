# Tokenomics – Aurevion (AUR)

- Total Supply: 10,000,000
- Buy/Sell Tax: 0%
- Minting: Disabled
- Proxy: No
