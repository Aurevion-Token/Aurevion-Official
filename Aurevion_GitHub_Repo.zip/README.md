# Aurevion (AUR)

Aurevion (AUR) is a transparent and community-driven token on BSC designed for long-term growth and utility.

## Key Highlights
- Verified Contract
- Fixed Supply: 10,000,000 AUR
- Non-mintable
- 0% Buy/Sell Tax
- Low Honeypot Risk
